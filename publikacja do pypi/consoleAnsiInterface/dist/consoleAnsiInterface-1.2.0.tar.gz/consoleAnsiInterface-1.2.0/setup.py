import setuptools

setuptools.setup(
    name='consoleAnsiInterface',
    version='1.2.0',
    author='szachy-a',
    description='Console interface with ANSI sequences for Windows',
    packages=['consoleAnsiInterface'],
    install_requires=['cursor']
)
